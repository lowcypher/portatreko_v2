<style type="text/css">
  span {
  font: 18px Arial, sans-serif;
  display: inline-block;
  transform: rotate(180deg);
}
</style>
 
<footer class="fixed-bottom">
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)" >
        <p class="text-center" style='color:white'> <span>&copy;</span> <?php echo date("Y"); ?> - VDGM666 - 
        <a class="text-white" href="https://www.mariomedeiros.eti.br" target="_blank">Mario Medeiros - Disaster Developer - Sistema PortaTreko</a></p>
      </div>
</footer>