<?php
session_start(); /* Inicia a Sessão */

// Arquivo onde estão armazenados usuarios e senhas
$usersFile = '.users';

// Função para copiar um diretório e seu conteúdo
function copyDir($source, $destination) {
    if (is_dir($source)) {
        if (!is_dir($destination)) {
            mkdir($destination, 0777, true);
        }

        $files = scandir($source);
        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                copyDir("$source/$file", "$destination/$file");
            }
        }
    } elseif (file_exists($source)) {
        copy($source, $destination);
    }
}

if (isset($_POST['Submit'])) {
    /* Define nome de usuário e associa array de senhas */
    $logins = array_map('str_getcsv', file($usersFile));

    /* Checagem e valida usuarios e senhas enviados como novas variáveis */
    $Username = isset($_POST['Username']) ? $_POST['Username'] : '';
    $Password = isset($_POST['Password']) ? $_POST['Password'] : '';

    /* Checa usuario e senha definidos no array */
    $loginValid = false;
    foreach ($logins as $login) {
        if ($login[0] == $Username && $login[1] == $Password) {
            $loginValid = true;
            break;
        }
    }

    if ($loginValid) {
        /* Sucesso: envia para o espaço do usuario */
        $_SESSION['UserData']['Username'] = $Username;

        // Cria a URL para o usuario e o seus diretório e redireciona 
        $userDirectory = 'portatreko/' . $Username;
        header("location: $userDirectory");
        exit;
    } else {
        $loginMsg = "<style='color:red'>Login Inválido";
    }
}

if (isset($_POST['Register'])) {
    $newUsername = isset($_POST['NewUsername']) ? $_POST['NewUsername'] : '';
    $newPassword = isset($_POST['NewPassword']) ? $_POST['NewPassword'] : '';

    // Verifique se o nome de usuário já existe
    $users = array_map('str_getcsv', file($usersFile));
    $existingUsernames = array_column($users, 0);

    if (in_array($newUsername, $existingUsernames)) {
        $registrationMsg = "<style='color:red'>Usuário Já Existe. Por Favor Escolha Outro";
    } else {
        // Adicione o novo usuário aos dados existentes
        $newUser = [$newUsername, $newPassword];
        $users[] = $newUser;

        // Salve os dados atualizados no arquivo .users
        $fileContents = array_map(function ($row) {
            return implode(',', $row);
        }, $users);
        file_put_contents($usersFile, implode("\n", $fileContents));

        // Crie o diretório do usuário
        $userDirectory = 'portatreko/' . $newUsername;
        if (!file_exists($userDirectory)) {
            mkdir($userDirectory, 0777, true);

            // Copie os arquivos/diretórios do sistema de upload para o diretório do usuário
            $sourceDir = 'sistema_upload'; // Diretório de origem dos arquivos do sistema de upload
            copyDir($sourceDir, $userDirectory);
        }
        $registrationMsg = "<style='color:green'>Registro OK! Faça login!";
    }
}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Sistema PortaTreko - Login</title>
    <!-- Adicione o link para o Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/portatreko.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <h1 class="mt-5" style='color:white'>Sistema PortaTreko</h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="row">
                <div class="col-md-6">
                    <form action="" method="post">
                        <!-- Formulário de Login -->
                        <div class="card mt-4">
                            <div class="card-header">
                                <h3 class="text-center">Login</h3>
                            </div>
                            <div class="card-body">
                                <?php if (isset($loginMsg)) { ?>
                                    <div class="alert alert-danger"><?php echo $loginMsg; ?></div>
                                <?php } ?>
                                <div class="form-group">
                                    <label for="Username">Usuário</label>
                                    <input type="text" class="form-control" name="Username" id="Username" required>
                                </div>
                                <div class="form-group">
                                    <label for="Password">Senha</label>
                                    <input type="password" class="form-control" name="Password" id="Password" required>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block" name="Submit">Login</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                    <form action="" method="post">
                        <!-- Formulário de Registro de Usuário -->
                        <div class="card mt-4">
                            <div class="card-header">
                                <h3 class="text-center">Registro</h3>
                            </div>
                            <div class="card-body">
                                <?php if (isset($registrationMsg)) { ?>
                                    <div class="alert alert-success"><?php echo $registrationMsg; ?></div>
                                <?php } ?>
                                <div class="form-group">
                                    <label for="NewUsername">Usuário</label>
                                    <input type="text" class="form-control" name="NewUsername" id="NewUsername" required>
                                </div>
                                <div class="form-group">
                                    <label for="NewPassword">Senha</label>
                                    <input type="password" class="form-control" name="NewPassword" id="NewPassword" required>
                                </div>
                                <button type="submit" class="btn btn-success btn-block" name="Register">Registrar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="text-center mt-3">
        <a href="portatreko_publico/" class="btn btn-primary">Acessar Arquivos Públicos</a>
    </div>
</div>
<!-- Adicione o link para o Bootstrap JS (opcional) -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php include 'footer.php'; ?>