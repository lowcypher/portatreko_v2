<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- <meta http-equiv="refresh" content="3;url=index.php"> <!-- Redirecionar para index.php após 3 segundos -->
    <title>Sucesso</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/background1.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <div class="alert alert-success" role="alert">
            <h4 class="alert-heading">Upload de Arquivos Concluído!</h4>
            <?php
                if (isset($_GET['files'])) {
                    $uploadedFiles = explode(',', $_GET['files']);
                    echo "<p>Os seguintes arquivos foram enviados com sucesso:</p>";
                    echo "<ul>";
                    foreach ($uploadedFiles as $file) {
                        echo "<li>$file</li>";
                    }
                    echo "</ul>";
                }
            ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php include 'footer.php'; ?>