<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">Sistema de Upload</a>

    <!-- Links para as páginas de listagem de arquivos -->
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" href="listagem_pdfs.php">PDFs</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="listagem_imagens.php">Imagens</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="listagem_docs.php">Docs</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="listagem_planilhas.php">Planilhas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="listagem_pacotes.php">Pacotes</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="listagem_geral.php">Todos Arquivos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../../logout.php">Sair</a>
        </li>
    </ul>
    

    <form class="form-inline my-2 my-lg-0" action="search.php" method="get">
        <input class="form-control mr-sm-2" type="search" placeholder="Buscar arquivos" name="query">
        <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Buscar</button>
    </form>
</nav>
 
