<?php
session_start();

// Função para copiar um arquivo para a área pública
function compartilharArquivo($origem, $destino) {
    if (copy($origem, $destino)) {
        return true;
    } else {
        return false;
    }
}

// Verificar se o botão "Compartilhar" foi clicado
if (isset($_POST['compartilhar']) && isset($_POST['arquivo'])) {
    $arquivo = $_POST['arquivo'];
    $nomeUsuario = $_SESSION['UserData']['Username'];
    $arquivoOrigem = "/home/mario/public_html/testes/portatreko_v2/portatreko/" . $nomeUsuario . "/uploads/" . $arquivo;
    $arquivoDestino = "/home/mario/public_html/testes/portatreko_v2/portatreko_publico/uploads/compartilhados/" . $arquivo;

    if (compartilharArquivo($arquivoOrigem, $arquivoDestino)) {
        $mensagem = "Arquivo compartilhado com sucesso!";
    } else {
        $mensagem1 = "Falha ao compartilhar o arquivo.";
    }
}

// Função para listar arquivos de planilhas
function listArquivosPlanilhas($dir) {
    $arquivosPlanilhas = [];
    if (is_dir($dir)) {
        $files = scandir($dir);
        foreach ($files as $file) {
            $filePath = $dir . '/' . $file;
            $extensao = pathinfo($file, PATHINFO_EXTENSION);
            if ($file !== '.' && $file !== '..' && in_array($extensao, ['xls', 'xlsx'])) {
                $arquivosPlanilhas[] = $filePath;
            }
        }
    }
    return $arquivosPlanilhas;
}

$uploadDir = "uploads/";
$arquivosPlanilhas = listArquivosPlanilhas($uploadDir);

// Configuração da paginação
$perPage = 5; // Quantidade de itens por página
$totalItems = count($arquivosPlanilhas);
$totalPages = ceil($totalItems / $perPage);

if (isset($_GET['page']) && is_numeric($_GET['page'])) {
    $currentPage = min(max(1, $_GET['page']), $totalPages);
} else {
    $currentPage = 1;
}

$offset = ($currentPage - 1) * $perPage;
$filesToDisplay = array_slice($arquivosPlanilhas, $offset, $perPage);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Listagem de Arquivos de Planilhas (XLS, XLSX)</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/background1.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Listagem de Arquivos de Planilhas (XLS, XLSX)</h2>
    <ul class="list-group">
        <?php
        if (!empty($filesToDisplay)) {
            foreach ($filesToDisplay as $planilha) {
                echo '<li class="list-group-item">';
                echo '<a href="' . $planilha . '" target="_blank">' . basename($planilha) . '</a>';
                echo '<form method="post" action="listagem_planilhas.php">';
                echo '<input type="hidden" name="arquivo" value="' . basename($planilha) . '">';
                echo '<button type="submit" name="compartilhar" class="btn btn-primary">Compartilhar</button>';
                echo '</form>';
                echo '</li>';
            }
        } else {
            echo '<li class="list-group-item">Nenhuma planilha encontrada.</li>';
        }
        ?>
    </ul>

    <!-- Paginação -->
    <nav aria-label="Páginação">
        <ul class="pagination">
            <?php
            if ($totalPages > 1) {
                // Botão "Primeira"
                echo '<li class="page-item"><a class="page-link" href="listagem_planilhas.php?page=1">Primeira</a></li>';

                // Botões numéricos
                for ($i = 1; $i <= $totalPages; $i++) {
                    echo '<li class="page-item';
                    if ($i == $currentPage) {
                        echo ' active';
                    }
                    echo '"><a class="page-link" href="listagem_planilhas.php?page=' . $i . '">' . $i . '</a></li>';
                }

                // Botão "Última"
                echo '<li class="page-item"><a class="page-link" href="listagem_planilhas.php?page=' . $totalPages . '">Última</a></li>';
            }
            ?>
        </ul>
    </nav>

    <!-- Mensagens de sucesso/erro -->
    <?php
    if (isset($mensagem)) {
        echo '<div class="mt-3 alert alert-success" role="alert">' . $mensagem . '</div>';
    } elseif (isset($mensagem1)) {
        echo '<div class="mt-3 alert alert-danger" role="alert">' . $mensagem1 . '</div>';
    }
    ?>

</div>

<!-- Scripts Bootstrap e jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
<?php include 'footer.php'; ?>
