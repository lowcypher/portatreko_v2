<?php

define('UPLOAD_DIR', '/home/mario/public_html/portatreko/portatreko/');
define('PUBLIC_DIR', '/home/mario/public_html/portatreko/portatreko_publico/uploads/compartilhados/');
 
