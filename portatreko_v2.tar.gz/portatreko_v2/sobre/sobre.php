<!doctype html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Mario Medeiros &mdash; PortaTreko &mdash; Sobre</title>
<meta name="description" content="Page description goes here">
<!-- ******************************************************************************************
Set the type and color theme here - the Pro version contains additional themes -->
<link href="css/willamette_type5_color1.css" rel="stylesheet">
<link href="css/copyleft.css" rel="stylesheet">
<!--  ************************************************************************************* -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<script src="js/vendor/modernizr.js"></script>
</head>
<body>
<header>
	<div class="row">
		<div class="small-12 medium-12 large-12 columns">
			<h2><a href="https://www.mariomedeiros.eti.br" taget="_blank">Mario Medeiros - Disaster Developer</a></h2><br>
            <h2>Sobre o PortaTreko</h2>
		</div>
	</div>
</header>

<?php
include ("menu.php");
?>

<div class=" section-bg-color1 ">
	<div class="row first-row">
		<div class="small-12 medium-6 large-6 columns">
			<h3>Sistema de Compartilhamento de Arquivos</h3>
            <p>
			Este sistema tem como premissa a simples organização, armazenamento e compartilhamento de arquivos em uma pequena rede local.
Não pretende substituir nenhum sistema robusto como um Owncloud ou um sistema baseado em SMB ou SAMBA.

Serve como uma solução rápida e ágil de repositório de arquivos para distribuir entre usuários da rede.

Esclarecido isso, vamos às descrições básicas do sistema.

Escrito em PHP (backend), HTML5 e Bootstrap (frontend) esse sistema não utiliza bancos de dados para armazenar arquivos.
Necessário um webserver configurado para rodar PHP. Utilizei o Apache Server version: Apache/2.4.56 (Debian) e PHP 7.4 em Debian. 
O sistema grava os arquivos em diretórios do webserver.
</p>
<h3>Utilizando o sistema</h3>
            <p>
			Esse sistema é divido em duas partes, por assim dizer.
A primeira a área de usuário com login e senha. 
Não existe nenhum usuário cadastrado no sistema. Registre um. 

Ao registrar um usuário, o script cria um diretório exclusivo desse novo usuário e faz uma cópia do sistema completo do PortaTreko.
Toda vez que o usuário se logar, será redirecionado para seu espaço. Será criado um espaço para cada usuário.

Os logins e senhas estarão gravados no arquivo padrão CSV. É o arquivo .users e este arquivo como pode ver, é oculto e sem extensão.
Um mínimo de segurança, que sim é vulnerável, mas como eu disse, é um sistema simples para soluções rápidas para pequenos ambientes.
Lembre-se disso. Se isso não lhe atende, não o use. Simples assim.

</p>
            </div>
		<div class="small-12 medium-6 large-6 columns">
			
			<p>
Existe a segunda parte do sistema que é a parte de arquivos públicos. Aqui não é necessário ter login no sistema. Se precisar compartilhar 
arquivos, é só adicionar e pronto. Ficarão todos num mesmo local. Para acesso aberto na rede.

Fiz alguns ajustes nos arquivos PHP utilizando session para poder limitar o acesso somente com usuário logado.
Pode não funcionar perfeitamente, uma vez que não tem os usuários registrados em banco de dados e não está implementado ainda formas mais agressivas de segurançs.

O sistema se propõe a ser simples para uso num grupo em uma rede local. Adicionei o mínimo de segurança de acesso.
Caso necessite de maior segurança, poderá ajustar os códigos ou então avaliar se esse sistema é o adequado à sua necessidade.
			<p>
            Este sistema possui os rescursos de área pública de arquivos, onde estarão os arquivos disponíveis na rede local
			sem a necessidade de login para acessar. Lembre-se de que este é um espaço em que qualquer um na rede pode acessar.
			<p> Para ter um espaço reservado para seus arquivos privativos, é necessário criar um login na área de registro. Para nomes de usuário
			tente utilizar o mais simples possível, sem caracteres especiais, sem espaço e tudo em minúsculos. Além de ser recomendado é
			considerado uma boa prática.
			<p>O sistema possui ainda busca dos arquivos e a possbilidade de compartilhar seus arquivos com demais usuários. A limitação 
				é: os arquivos compartilhados ficarão na ára pública do sistema. Avalie se esta condição é viável para suas atividades.
				O sistema possui também uma listagem geral de todos os arquivos, caso necessite localizar na lista todos os arquivos. Foi previsto
				o uso para alguns tipos de arquivos mas nos testes foi possível subir arquivos que não constam na lista, como arquivos com extensão TXT.
            </p>
			
			
			<h3>Sistema</h3>
            <p>Autor: <a href="https://www.mariomedeiros.eti.br" taget="_blank">Mario Medeiros - Disaster Developer</a>
			<p>Repositório: <a href="https://github.com/lowcypher" taget="_blank">GitHub</a>
			<p>Data: 2023-11-15
<p>Versão: 2.0
<p>Pode ser alterado e redistribuído. Mencione os devidos créditos.
<p>Licença: GPL V3 e Creative Commons V4 CC-BY
			</p>
		</div>
	</div>
</div>
<!--
<footer class="section-bg-color2">
	<div class="row">
		<div class="small-12 medium-12 large-12 columns">
			<ul>
				<li> <span class="copy-left">©</span> 2023 - Mario Medeiros - CopyLeft.</li>
				<!--<li><a href="sobre.php">Sobre o Livro</a></li>
				<li><a href="sobreoteste.php">Sobre o Teste</a></li>	-->			
				<!-- *****************************************************************************************
				The "Powered by Type & Grids" link in the footer is required in the Free version
				typeandgrids.com/pirates -->
<!--				<li>Powered by <a href="http://www.typeandgrids.com" target="_blank">Type &amp; Grids</a></li> !>
				<!--  ************************************************************************************ -->
<!--			</ul>			
			<div class="social-icons">
				<div class="footer-badge">
					<a href="https://www.mariomedeiros.eti.br"><img src="img/logo1.png" width="57" height="57" alt="Home" /></a>
				</div>
			</div>
		</div>
	</div>
</footer> -->
<?php
include ("footer.php");
?>
<script src="js/vendor/jquery.min.js"></script>
<script src="js/foundation.min.js"></script>
<script src="js/willamette.js"></script>
</body>
</html>
