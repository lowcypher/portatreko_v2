<?php
?>
<html>
<nav>
	<div class="row">
		<div class="small-12 medium-12 large-12 columns">			
			<ul>
			<li><a href=".." >Voltar Ao PortaTreko</a></li>

			<li><a href="https://www.mariomedeiros.eti.br" target="_blank" >Acessar O Site Mario Medeiros</a></li>
			</ul>
		</div>
	</div>
</nav>
</html>
