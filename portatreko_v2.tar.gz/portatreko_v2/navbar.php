<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">Sistema de Upload</a>
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" href="sobre/sobre.php">Sobre o Sistema</a>
        </li>
    </ul>
</nav>